import blog001 from "./blogs/a/image001.jpg"

export default [
  {
    id: "1",
    image: blog001,
    title: "Discover MyLuna AI",
    date: "2024-01-01",
    description:
      "Discover MyLuna AI: A New Alternative to CrushOn.AI and Character.AI Without Content Filters, Including NSFW Options [October 2024]",
  },
]
